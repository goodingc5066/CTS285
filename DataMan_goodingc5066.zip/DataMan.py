# -*- coding: utf-8 -*-
"""
Created on Fri Oct 30 12:01:50 2020
Chrystian Gooding
10/30/2020
DataMan
This Program will emulate the DataMan Calculators.
"""
def answerChecker():
    print("Welcome to the AnswerChecker\nPlease Select from the option below\n"
          +"1.Add\n2.Subtract\n3.Multiply\n4.Divide")
    
   
    userchoice = input("What is your selection:")
    #if user chooses 1 will run code for simple addition
    if (userchoice == "1"):
       
        fNum = int(input("Enter the first number being added:"))
       
        sNum = int(input("Enter the second number being added:"))
       
        ans = fNum + sNum 
       
        userans =(int(input ("What is the answer to the sum:")))
        
        if (userans == ans):
            print("*************CORRECT!!!**************")
        else:
            print("EEEEEEEEEEEEEEEEEEEEEEEE")
    # if user chooses 2 will run code for simple subtraction   
    elif (userchoice == "2"):
        
        fNum = int(input("Enter the number being subtracted:"))
       
        sNum = int(input("Enter the second number which will do the subtraction:"))
       
        ans = fNum - sNum 
       
        userans =(int(input ("What is the answer to the sum:")))
        
        if (userans == ans):
            print("*************CORRECT!!!**************")
        else:
            print("EEEEEEEEEEEEEEEEEEEEEEEE")
    # if user chooses 3 will run code for simple multiplication        
    elif(userchoice == "3"):
         
          fNum = int(input("Enter the number being multiplied:"))
        
          sNum = int(input("Enter the second number being multiplied:"))
        
          ans = fNum * sNum 
        
          userans =(int(input("What is the answer to the sum:")))
         
          if (userans == ans):
              print("*************CORRECT!!!**************")
          else:
              print("EEEEEEEEEEEEEEEEEEEEEEEE")
    #if user enters 4 will run code for division with a remainder
    elif(userchoice == "4"):
        
        fNum = int(input("Enter the number being divided:"))
       
        sNum = int(input("Enter the second number which will do the division:"))
        
        quotient, remainder = divmod(fNum,sNum)
        
        userquot =(int(input("What is the quotient:")))
        
        userrmd =(int(input("What is the remainder:")))
        
        if (userquot == quotient and userrmd == remainder):
              print("*************CORRECT!!!**************")
        else:
              print("EEEEEEEEEEEEEEEEEEEEEEEE")
            

def main():  
    playAgain = 'y'
    while (playAgain =='y'):              
        answerChecker()
        playAgain = input ("Play again? (y/n)")
    
    print("Goodbye!")
    
main()







