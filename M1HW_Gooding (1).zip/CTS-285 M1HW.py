# -*- coding: utf-8 -*-
# Chrystian Gooding
#8/22/2020
# Create a simple calculator program that can add, subtract, multiply and 
#divide. 
keepGoing = 'yes'
while keepGoing == 'yes':
    choice = '';
    while choice != '5':
        
    # Menu Print Statements
        print("Welcome to the calculator program.")
        print("1. Add")
        print("2. Subtract")
        print("3. Divide")
        print("4. Multiply")
        print("5. Exit")
        choice = input("Enter a choice:")
    # Runs if user enters 1 and will add two numbers
        if choice == '1':
            print("Add")
            number1 = int(input("Enter a number 1:"))
            number2 = int(input("Enter a number 2:"))
            sum = number1 + number2
            print("----------------------------------------")
            print(number1, "+", number2, "=", sum)
            print("----------------------------------------")
            
                
    # Runs if user enters 2 and will subtract two numbers
        
        elif choice == '2':
            print("Subtract")
            number1 = int(input("Enter a number 1:"))
            number2 = int(input("Enter a number 2:"))
            sum = number1 - number2
            print("----------------------------------------")
            print(number1, "-", number2, "=", sum)
            print("----------------------------------------")
            
            
    # Runs if user enters 3 and will divide two numbers
        
            
        elif choice == '3':
            print("Divide")
            number1 = int(input("Enter a number 1:"))
            number2 = int(input("Enter a number 2:"))
            sum = number1 / number2
            print("----------------------------------------")
            print(number1, "/", number2, "=", sum)
            print("----------------------------------------")
            
    # Runs if user enters 4 and will multiply two numbers
              
        
        elif choice == '4':
            print("Multiply")
            number1 = int(input("Enter a number 1:"))
            number2 = int(input("Enter a number 2:"))
            sum = number1 * number2
            print("----------------------------------------")
            print(number1, "*", number2, "=", sum)
            print("----------------------------------------")
            
    # Runs if user enters 5 and will exit the program
               
            
        elif choice == '5':
            print("----------------------------------------")
            print("Thanks for using the Calculator Goodbye!!")
            print("----------------------------------------")
            keepGoing = 'no'
    # If user enters anything other than 1 to 5 will give error promting correct 
    #number
        else:
            print("----------------------------------------")
            print("Please enter a listed number")
            print("----------------------------------------")
            
        
        
        
        
        
        
        
        

        
        
        
        
        