# -*- coding: utf-8 -*-
"""
Created on Fri Oct 30 12:01:50 2020
Chrystian Gooding
10/30/2020
DataMan
This Program will emulate the DataMan Calculators.
"""

def answerChecker():
    print("Welcome to the AnswerChecker\nPlease Select from the option below\n"
          +"1.Add\n2.Subtract\n3.Multiply\n4.Divide")
    
    print("What is your selection:")
    
    userchoice = input()
    #if user chooses 1 will run code for simple addition
    if (userchoice == "1"):
       
        fNum = int(print("Enter the first number being added:"))
       
        sNum = int(print("Enter the second number being added:"))
       
        ans = fNum + sNum 
       
        userans(int(print ("What is the answer to the sum:"))
        
        if (userans == ans):
            print("*************CORRECT!!!**************")
        else:
            print("EEEEEEEEEEEEEEEEEEEEEEEE")
    # if user chooses 2 will run code for simple subtraction   
    elif (userchoice == "2"):
        
        fNum = int(print("Enter the number being subtracted from:"))
       
        sNum = int(print("Enter the second number which will subtract:"))
       
        ans = fNum - sNum 
       
        userans(int(print ("What is the answer to the sum:"))
        
        if (userans == ans):
            print("*************CORRECT!!!**************")
        else:
            print("EEEEEEEEEEEEEEEEEEEEEEEE")
    # if user chooses 3 will run code for simple multiplication        
    elif(userchoice == "3"):
         
         fNum = int(print("Enter the number being multiplied:"))
        
         sNum = int(print("Enter the second number being multiplied:"))
        
         ans = fNum * sNum 
        
         userans(int(print ("What is the answer to the sum:"))
         
         if (userans == ans):
             print("*************CORRECT!!!**************")
         else:
             print("EEEEEEEEEEEEEEEEEEEEEEEE")
            
                

def main():                
    answerChecker()
    
main()

