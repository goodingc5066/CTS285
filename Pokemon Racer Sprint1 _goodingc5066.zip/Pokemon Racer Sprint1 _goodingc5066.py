# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 13:36:53 2020

@author: Chrystian
Chrystian Gooding
9/30/2020
Sprint1
"""

import sys
def playGame():
    print("GAME RULES\n"
          "Both players will be allowed two pokemon with 5hp each"
          " when either player loses both pokemon game is finished!!!!\n")
    print("*****MainMenu*****")
    print("(1)Start Game\n"
          "(2)End Game")
    print("Please select a choice:")
    
    playerChoice = int(input())
    
    if (playerChoice == 1):
        print(" Please choose your first pokemon:")
    
    
  
    if (playerChoice == 2):
        sys.exit
        print("Goodbye!!")




  
    
def main(): 
      
      playAgain = 'y'
      while (playAgain =='y'):
          playGame()
          playAgain = input ("Do you want to play again? (y/n)")
    
      print("Goodbye!")
    
main()

