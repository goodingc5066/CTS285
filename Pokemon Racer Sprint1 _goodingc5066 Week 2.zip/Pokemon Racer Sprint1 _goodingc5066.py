# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 13:36:53 2020

@author: Chrystian
Chrystian Gooding
9/30/2020
Sprint1
"""

import sys
def playGame():
    
    print("GAME RULES\n"
          "Both user and computer will be allowed two pokemon with 5hp each"
          " when either player loses both pokemon game is finished!!!!\n")
    print("*****MainMenu*****")
    print("(1)Start Game\n"
          "(2)End Game")
    print("Please select a choice:")
    
    playerChoice = int(input())
    
    if (playerChoice == 1):
        print("1.Squirtle |2.Piplup\n"+
              "3.Bulbasaur|4.Snivy\n"+
              "5.Pikachu  |6.Mareep\n"+
              "7.Thorchic |8.Tepig\n"+
              "9.Rookidee |10.Eevee")
        print("Please choose your first pokemon:")
        pokemonChoice1 = input()
        
        if(pokemonChoice1 == "1"):
            print("You have chosen Squirtle as your first Pokemon.")
            pokemon1 = "Squirtle"
        elif(pokemonChoice1 == "2"):
            print("You have chosen Piplup as your first Pokemon.")
            pokemon1 ="Piplup"
        elif(pokemonChoice1 == "3"):
            print("You have chosen Bulbasaur as your first Pokemon.")
            pokemon1 ="Bulbasaur"
        elif(pokemonChoice1 == "4"):
            print("You have chosen Snivy as your first Pokemon.")
            pokemon1 ="Snivy"
        elif(pokemonChoice1 == "5"):
            print("You have chosen Pikachu as your first Pokemon.")
            pokemon1 ="Pikachu"
        elif(pokemonChoice1 == "6"):
            print("You have chosen Mareep as your first Pokemon.")
            pokemon1 ="Mareep"
        elif(pokemonChoice1 == "7"):
            print("You have chosen Thorchic as your first Pokemon.")
            pokemon1 ="Thorchic"
        elif(pokemonChoice1 == "8"):
            print("You have chosen Tepig as your first Pokemon.")
            pokemon1 ="Tepig"
        elif(pokemonChoice1 == "9"):
            print("You have chosen Rookidee as your first Pokemon.")
            pokemon1 ="Rookidee"
        elif(pokemonChoice1 == "10"):
            print("You have chosen Eevee as your first Pokemon.")
            pokemon1 ="Eevee"
        else:
            print("Select from the options available")
        
        print("Please choose your second pokemon:")
        pokemonChoice2 = input()
        
        if(pokemonChoice2 == "1"):
            print("You have chosen Squirtle as your second Pokemon.")
            pokemon2 = "Squirtle"
        elif(pokemonChoice2 == "2"):
            print("You have chosen Piplup as your second Pokemon.")
            pokemon2 ="Piplup"
        elif(pokemonChoice2 == "3"):
            print("You have chosen Bulbasaur as your second Pokemon.")
            pokemon2 ="Bulbasaur"
        elif(pokemonChoice2 == "4"):
            print("You have chosen Snivy as your second Pokemon.")
            pokemon2 ="Snivy"
        elif(pokemonChoice2 == "5"):
            print("You have chosen Pikachu as your second Pokemon.")
            pokemon2 ="Pikachu"
        elif(pokemonChoice2 == "6"):
            print("You have chosen Mareep as your second Pokemon.")
            pokemon2 ="Mareep"
        elif(pokemonChoice2 == "7"):
            print("You have chosen Thorchic as your second Pokemon.")
            pokemon2 ="Thorchic"
        elif(pokemonChoice2 == "8"):
            print("You have chosen Tepig as your second Pokemon.")
            pokemon2 ="Tepig"
        elif(pokemonChoice2 == "9"):
            print("You have chosen Rookidee as your second Pokemon.")
            pokemon2 ="Rookidee"
        elif(pokemonChoice2 == "10"):
            print("You have chosen Eevee as your second Pokemon.")
            pokemon2 ="Eevee"
        else:
            print("Select from the options available")
        
        print("The Pokemon you have selected are " +pokemon1+ " and "+ 
              pokemon2+"."+"\n\nNow it is the Computers Turn!!")
    
    
  
    elif (playerChoice == 2):
        sys.exit
        print("Thank you for playing!!!")
        
  



  
    
def main(): 
      
    
  playGame()

main()






