# -*- coding: utf-8 -*-
"""
Created on Fri Oct 30 12:01:50 2020
Chrystian Gooding
10/30/2020
DataMan
This Program will emulate the DataMan Calculators.
"""
from random import randint
score = 0
def memoryBanker():
     while True:
         global score
               
         print("1.RandomQuestions\n2.Exit")    
         choice = input("What is your selection:")         
         if (choice == "1"):
             for x in range (10):
                 fNum = randint(1, 10)
                 sNum = randint(1, 10)                  
                 print("Select either (1)Addition, (2)Multiplication or (3)Subtraction:")
                 operator = input("1, 2 or 3:")
                 if (operator == "1"):
                     question = int(input("What is " + str(fNum) + "+" + str(sNum) + "?"))
                     answer = fNum + sNum
                     if question == answer:
                         score = score + 1
                         print("Your score is " + str(score))
                     else:
                         print("Your score is " + str(score))
                         
                 elif (operator == "2"):                     
                     question = int(input("What is " + str(fNum) + "*" + str(sNum) + "?"))
                     answer = fNum * sNum
                     if question == answer:
                         score = score + 1
                         print("Your score is " + str(score))
                     else:
                         print("Your score is " + str(score))
                         
                         
                 elif (operator == "3"):                     
                     question = int(input("What is " + str(fNum) + "-" + str(sNum) + "?"))
                     answer = fNum - sNum
                     if question == answer:
                         score = score + 1
                         print("Your score is " + str(score))
                     else:
                         print("Your score is " + str(score))
             print("Your Final Score is "+ str(score)+ " out of 10.")
             print("______________________________________________")
                         
       
         else:
            print("You have chosen to close the DataMan GoodBye!!!!!")
            print("______________________________________________")
            break
            
         
        
def answerChecker():
    while True: 
        print("Welcome to the AnswerChecker\nPlease Select from the option below\n"
              +"1.Add\n2.Subtract\n3.Multiply\n4.Divide\n5.Exit")
    
  
        userchoice = input("What is your selection:")
        #if user chooses 1 will run code for simple addition
        if (userchoice == "1"):
           
            fNum = int(input("Enter the first number being added:"))
           
            sNum = int(input("Enter the second number being added:"))
           
            ans = fNum + sNum 
           
            userans =(int(input ("What is the answer to the sum:")))
            
            if (userans == ans):
                print("*************CORRECT!!!**************")
                print("The answer was:",ans)
                print("______________________________________________")
            else:
                print("EEEEEEEEEEEEEEEEEEEEEEEE")
                print("The answer was:",ans)
                print("______________________________________________")
        # if user chooses 2 will run code for simple subtraction   
        elif (userchoice == "2"):
            
            fNum = int(input("Enter the number being subtracted:"))
           
            sNum = int(input("Enter the second number which will do the subtraction:"))
           
            ans = fNum - sNum 
           
            userans =(int(input ("What is the answer to the sum:")))
            
            if (userans == ans):
                print("*************CORRECT!!!**************")
                print("The answer was:",ans)
                print("______________________________________________")
            else:
                print("EEEEEEEEEEEEEEEEEEEEEEEE")
                print("The answer was:",ans)
                print("______________________________________________")
        # if user chooses 3 will run code for simple multiplication        
        elif(userchoice == "3"):
             
              fNum = int(input("Enter the number being multiplied:"))
            
              sNum = int(input("Enter the second number being multiplied:"))
            
              ans = fNum * sNum 
            
              userans =(int(input("What is the answer to the sum:")))
             
              if (userans == ans):
                print("*************CORRECT!!!**************")
                print("The answer was:",ans)
                print("______________________________________________")
              else:
                print("EEEEEEEEEEEEEEEEEEEEEEEE")
                print("The answer was:",ans)
                print("______________________________________________")
        #if user enters 4 will run code for division with a remainder
        elif(userchoice == "4"):
            
            fNum = int(input("Enter the number being divided:"))
           
            sNum = int(input("Enter the second number which will do the division:"))
            
            quotient, remainder = divmod(fNum,sNum)
            
            userquot =(int(input("What is the quotient:")))
            
            userrmd =(int(input("What is the remainder:")))
            
            if (userquot == quotient and userrmd == remainder):
                  print("*************CORRECT!!!**************")
                  print("The answer was:",quotient ,"r",remainder)
                  print("______________________________________________")
            else:
                  print("EEEEEEEEEEEEEEEEEEEEEEEE")
                  print("The answer was:",quotient ,"r",remainder)
                  print("______________________________________________")
        else:
            print("You have chosen to exit the AnswerChecker!!!!!")
            print("______________________________________________")
            break

def main():  
    while True: 
        print("Welcome to the DataMan Calculator\nPlease select your function:")
        print("1.AnswerChecker\n2.MemoryBanker\n3.Exit")
        userchoice = input("What is your selection:")
        if (userchoice == "1"):
            answerChecker()
        elif (userchoice == "2"):
            memoryBanker()
        else:
            print("You have chosen to close the DataMan GoodBye!!!!!")
            print("______________________________________________")
            break
                
main()